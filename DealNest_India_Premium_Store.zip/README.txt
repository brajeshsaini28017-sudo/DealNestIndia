DEALNEST INDIA — PREMIUM STORE
1. Open index.html in a browser.
2. The hero currently uses a CSS premium playback mockup, so it works without external assets.
3. To use a real looping product video, add assets/hero.mp4 and replace the .live block in index.html with a <video autoplay muted loop playsinline controls>.
4. Products, prices, logo text, payment gateway and WhatsApp checkout can be connected in script.js.
