const products=[
["iPhone 15 (128GB) Blue","📱","₹69,999","₹70,999","13% OFF","Best Seller"],
["Dell Inspiron 15 Core i5","💻","₹42,990","₹54,000","22% OFF","Top Rated"],
["Sony WH-1000XM5 Headphones","🎧","₹29,990","₹39,900","25% OFF","Limited"],
["Nike Men's Running Shoes","👟","₹4,499","₹6,999","36% OFF","Hot Deal"],
["boAt Wave Call Smartwatch","⌚","₹2,499","₹4,999","50% OFF","Best Seller"],
["Philips Air Fryer 4.1L","🍳","₹8,999","₹12,999","31% OFF","New Launch"]
];
let cart=[];
function render(){document.getElementById("grid").innerHTML=products.map((p,i)=>`<article class="product"><div class="pic"><span class="badge">${p[5]}</span>${p[1]}</div><div class="pinfo"><h3>${p[0]}</h3><div class="rating">★ ${4.3+i%5/10} (${(3+i*2)+".2"}k)</div><div class="price">${p[2]} <span class="old">${p[3]}</span><span class="off">${p[4]}</span></div><button class="add" onclick="add(${i})">🛒 Add to Cart</button></div></article>`).join("")}
function add(i){cart.push(products[i]);document.getElementById("count").textContent=cart.length;toast(products[i][0]+" added to cart");}
function openCart(){document.getElementById("drawer").style.display="block";document.getElementById("items").innerHTML=cart.length?cart.map((p,i)=>`<div class="cartitem"><span>${p[0]}</span><b>${p[2]}</b></div>`).join(""):"<p>Your cart is empty.</p>";document.getElementById("total").textContent="₹"+cart.reduce((s,p)=>s+Number(p[2].replace(/[₹,]/g,"")),0).toLocaleString("en-IN")}
function closeCart(){document.getElementById("drawer").style.display="none"}
function toast(t){let x=document.getElementById("toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
function subscribe(e){e.preventDefault();toast("You're subscribed to DealNest India!");e.target.reset()}
function doSearch(){let q=document.getElementById("search").value.toLowerCase();let hit=products.find(p=>p[0].toLowerCase().includes(q));if(q&&!hit)toast("No matching product found");else if(q){document.getElementById("products").scrollIntoView();toast("Showing results for "+q)}}
let live=true;function toggleLive(){live=!live;document.querySelector(".player button").textContent=live?"Ⅱ":"▶";document.querySelector("#bar").style.width=live?"22%":"0%"}
render();
